package com.edu.proyect.User.service;

import com.edu.proyect.User.model.Usuario;

public interface UsuarioService extends GenericService<Usuario, Integer> {

}
