package com.edu.proyect.User.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edu.proyect.User.model.Usuario;

public interface UsuarioRepo extends JpaRepository <Usuario, Integer>{

}
